package smi5.compilation.main;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

import smi5.compilation.anaLex.Categorie;
import smi5.compilation.anaLex.Scanner;
import smi5.compilation.anaLex.UniteLexicale;
import smi5.compilation.anaSyn.Parser;

/**
 * @author samir MBARKI
 * @version 06/11/2011
 */
public class Main {

	public static void main(String[] args) {
		Scanner anaLex=new Scanner("test.txt");
		//System.out.println(anaLex);
		Parser parser=new Parser();
		parser.lireProduction();
		parser.setNullable();
		parser.calculPremier();
		parser.getPremier();
		   System.out.println("Liste de premier");
	        Iterator iterator = parser.getPremier().entrySet().iterator();
	        while (iterator.hasNext()) {
	          Map.Entry mapentry = (Map.Entry) iterator.next();
	          System.out.println("le premier de    **"+mapentry.getKey()
	                            + "   **est" + mapentry.getValue());
	        } 
		parser.calculSuivant();
		parser.getSuivant();
		  System.out.println("Liste de suivants");
	        Iterator iterator2 = parser.getSuivant().entrySet().iterator();
	        while (iterator2.hasNext()) {
	          Map.Entry mapentry = (Map.Entry) iterator2.next();
	          System.out.println("le suivant de    **"+mapentry.getKey()
	                            + "   **est" + mapentry.getValue());
	        } 
		
		parser.calculPremierRegles();
		parser.remplirTableAnalyse();
		parser.initialiserPile();
		
		
		UniteLexicale ul=null;
		do {
			ul=anaLex.lexemeSuivant();
			//System.out.println(ul);
			if(ul.getCategorie().equals(Categorie.EOF))
				parser.analyserSyntaxe(Categorie.$);
			else		
				parser.analyserSyntaxe(ul.getCategorie());
		}
		while(ul.getCategorie()!=Categorie.EOF);
		
		
		
		
		
		parser.afficher();	
	}
	
}
