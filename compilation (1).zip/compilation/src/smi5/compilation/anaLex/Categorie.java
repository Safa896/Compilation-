package smi5.compilation.anaLex;
/**
 * @author samir MBARKI
 * @version 06/11/2011
 */
public enum Categorie{
	EOF,
	$,
	NUL,
	
	PAREND,
	PARENG,
	PLUS,
	FOIS,
	NOMBRE,
	ID,
	
	
	E,
	EPRIME,
	T,
	TPRIME,
	F;
	
	public static final int MIN=3, MAX=8, MAX1=13;
	public String toString() {
		return this.name().toLowerCase();
	}
	
	public static Categorie toCategorie(String s) {
		for(Categorie c:Categorie.values())
			  if(c.toString().equalsIgnoreCase(s))
				  return c;
		return null;
	}
	
	public boolean estTerminal() {
		return ordinal()>=MIN && ordinal()<=MAX;
	}
	
	public boolean estNonTerminal() {
		return ordinal()>MAX;
	}
}
