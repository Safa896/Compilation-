package smi5.compilation.anaLex;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 * @author samir MBARKI
 * @version 06/11/2011
 */
public class Scanner {
	private ArrayList<Character> fluxCaracteres;
	private int indiceCourant;
	private char caractereCourant;
	private boolean eof;
	
	public Scanner() {
		this("");
	}
	
	public Scanner(String nomFich) {
		BufferedReader f=null;
		int car=0;
		fluxCaracteres=new ArrayList<Character>();
		indiceCourant=0;
		eof=false;
		try {
			f=new BufferedReader(new FileReader(nomFich));
		}
		catch(IOException e) {
			System.out.println("taper votre texte ci-dessous (ctrl+z pour finir)");
			f=new BufferedReader(new InputStreamReader(System.in));
		}
		
		try {
			while((car=f.read())!=-1)
				fluxCaracteres.add((char)car);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void caractereSuivant() {
		if(indiceCourant<fluxCaracteres.size())
			caractereCourant=fluxCaracteres.get(indiceCourant++);
		else
			eof=true;
	}
	
	public void reculer() {
		if(indiceCourant>0)
			indiceCourant--;
	}
	
	public UniteLexicale lexemeSuivant() {
		caractereSuivant();
		
		while(eof || Character.isWhitespace(caractereCourant)) { 
			if (eof)
				return new UniteLexicale(Categorie.EOF, "");
			caractereSuivant();
		}
		
		if(Character.isLetter(caractereCourant))
			return getID();
		
		if(Character.isDigit(caractereCourant))
			return getNombre();
		
		if(caractereCourant=='+')
			return new UniteLexicale(Categorie.PLUS, "");
		
		if(caractereCourant=='*')
			return new UniteLexicale(Categorie.FOIS, "");
		if(caractereCourant=='(')
			return new UniteLexicale(Categorie.PARENG, "");
		if(caractereCourant==')')
			return new UniteLexicale(Categorie.PAREND, "");
		
		return null;
	}
	
	public UniteLexicale getID() {
		int etat=0;
		StringBuffer sb=new StringBuffer();
		while(true) {
			switch(etat) {
				case 0 : etat=1; 
						 sb.append(caractereCourant); 
						 break;
				case 1 : caractereSuivant();
						 if(eof)
							 etat=3;
						 else
							 if(Character.isLetterOrDigit(caractereCourant)) 
								 sb.append(caractereCourant);
							 else
								 etat=2;
						 break;
				case 2 : reculer();
						 return new UniteLexicale(Categorie.ID, sb.toString());
				case 3 : return new UniteLexicale(Categorie.ID, sb.toString());
			}
		}
	}
	
	public UniteLexicale getNombre() {
		int etat=0;
		StringBuffer sb=new StringBuffer();
		while(true) {
			switch(etat) {
			case 0 : etat=1; 
					 sb.append(caractereCourant); 
					 break;
			case 1 : caractereSuivant();
					 if(eof)
						 etat=3;
					 else
						 if(Character.isDigit(caractereCourant)) 
							 sb.append(caractereCourant);
						 else
							 etat=2;
					 break;
			case 2 : reculer();
					 return new UniteLexicale(Categorie.NOMBRE, sb.toString());
			case 3 : return new UniteLexicale(Categorie.NOMBRE, sb.toString());
			}
		}
		
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return fluxCaracteres.toString();
	}
	
	
}
