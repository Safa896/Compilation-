package smi5.compilation.anaSyn;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Stack;
import java.util.TreeMap;
import java.util.TreeSet;

import smi5.compilation.anaLex.Categorie;



public class Parser {
	private Categorie axiome;
	private TreeMap<Categorie,ArrayList<ArrayList<Categorie>>> production;
	private TreeMap<Categorie, Boolean> nullable;
	private TreeMap<Categorie, TreeSet<Categorie>> premier;
	private TreeMap<Categorie, TreeSet<Categorie>> suivant;
	private HashMap<ArrayList<Categorie>, TreeSet<Categorie>> premierRegles;
	private String fichierproduction;
	
	private Stack<Categorie> pile;
	
	private ArrayList [] [] TA;
	
	public Parser() {
		fichierproduction="grammaire.txt";
		production=new TreeMap<Categorie, ArrayList<ArrayList<Categorie>>>();
		nullable=new TreeMap<Categorie, Boolean>();
		premier=new TreeMap<Categorie, TreeSet<Categorie>>();
		suivant=new TreeMap<Categorie, TreeSet<Categorie>>();
		premierRegles=new HashMap<ArrayList<Categorie>, TreeSet<Categorie>>();
		
		TA=new ArrayList [Categorie.MAX1-Categorie.MAX][Categorie.MAX-Categorie.MIN+2];
		
		pile=new Stack<Categorie>();
	}
	
	public void initialiserPile() {
		pile.clear();
		pile.push(Categorie.$);
		pile.push(axiome);
	}
	
	public Categorie getAxiome() {
		return axiome;
	}

	public void setAxiome(Categorie axiome) {
		this.axiome = axiome;
	}

	public TreeMap<Categorie, ArrayList<ArrayList<Categorie>>> getProduction() {
		return production;
	}

	public void setProduction(TreeMap<Categorie, ArrayList<ArrayList<Categorie>>> production) {
		this.production = production;
	}

	public TreeMap<Categorie, Boolean> getNullable() {
		return nullable;
	}

	public void setNullable(TreeMap<Categorie, Boolean> nullable) {
		this.nullable = nullable;
	}

	public TreeMap<Categorie, TreeSet<Categorie>> getPremier() {
		return premier;
	}

	public void setPremier(TreeMap<Categorie, TreeSet<Categorie>> premier) {
		this.premier = premier;
	}

	public TreeMap<Categorie, TreeSet<Categorie>> getSuivant() {
		return suivant;
	}

	public void setSuivant(TreeMap<Categorie, TreeSet<Categorie>> suivant) {
		this.suivant = suivant;
	}

	public HashMap<ArrayList<Categorie>, TreeSet<Categorie>> getPremierRegles() {
		return premierRegles;
	}

	public void setPremierRegles(HashMap<ArrayList<Categorie>, TreeSet<Categorie>> premierRegles) {
		this.premierRegles = premierRegles;
	}

	public String getFichierproduction() {
		return fichierproduction;
	}

	public void setFichierproduction(String fichierproduction) {
		this.fichierproduction = fichierproduction;
	}

	public Stack<Categorie> getPile() {
		return pile;
	}

	public void setPile(Stack<Categorie> pile) {
		this.pile = pile;
	}

	public ArrayList[][] getTA() {
		return TA;
	}

	public void setTA(ArrayList[][] tA) {
		TA = tA;
	}

	public void afficher() {
		/*System.out.println(axiome);
		System.out.println(production);
		System.out.println(nullable);
		System.out.println(premier);
		System.out.println(suivant);
		System.out.println(premierRegles);*/
		String tab1[]= {"e","eprime","t","tprime","f"};
		String tab2[]= {"+","null","*","id","nombre","(",")","$"};
		for(int i=0;i<TA.length;i++) {
			System.out.println(tab1[i]);
			for(int j=0;j<TA[i].length;j++) {
			
				if(TA[i][j]==null)
					System.out.print("NULL ");
				else
					System.out.print(TA[i][j]);
			}
			System.out.println("");
		}
	}
	
	public void lireProduction() {
		setAxiome();
		try {
			BufferedReader br=new BufferedReader(new FileReader(fichierproduction));
			String ligne=null;
			while((ligne=br.readLine())!=null) {
				String t1[]=ligne.split("::=");
				ArrayList<Categorie> liste=new ArrayList<Categorie>();
				Categorie cl�=Categorie.toCategorie(t1[0]);
				ArrayList<ArrayList<Categorie>> valeur=production.get(cl�);
				String t2[]=t1[1].split("\\s+");
				for(int i=0;i<t2.length;i++)
					liste.add(Categorie.toCategorie(t2[i]));
				if(valeur==null) {
					valeur=new ArrayList<ArrayList<Categorie>>();
					valeur.add(liste);
					production.put(cl�,valeur);
				}
				else
					valeur.add(liste);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void setAxiome() {
		for(Categorie c:Categorie.values())
			if(c.estNonTerminal()) {
				axiome=c;
				return;
			}
	}
	
	public void setNullable() {
		
		nullable.put(Categorie.NUL, true);
		
		for(Categorie c:Categorie.values()) {	
			if(c.estTerminal())
				nullable.put(c, false);
			if(c.estNonTerminal()) {
				ArrayList<ArrayList<Categorie>> valeur=production.get(c);
				for(int i=0;i<valeur.size();i++) {
					if(valeur.get(i).get(0).equals(Categorie.NUL))
						nullable.put(c, true);
				}
			}
		}
		for(Categorie c:Categorie.values()) {
			if(c.estNonTerminal()) {
				ArrayList<ArrayList<Categorie>> valeur=production.get(c);
				for(int i=0;i<valeur.size();i++) {
					ArrayList<Categorie> prod=valeur.get(i);
					boolean b=true;
					for(int j=0;j<prod.size();j++) {
						if(nullable.get(c)!=null && nullable.get(c))
							break;
						if(nullable.get(prod.get(j))==null || !nullable.get(prod.get(j)))
							b=false;
					}
					nullable.put(c, b);
				}
			}
		}
	}
	
	public void calculPremier() {
		
		TreeSet<Categorie> ts=new TreeSet<Categorie>();
		ts.add(Categorie.NUL);
		premier.put(Categorie.NUL, ts);
		
		for(Categorie c:Categorie.values()) {
			if(c.estTerminal()) {
				TreeSet<Categorie> valeur=new TreeSet<Categorie>();
				valeur.add(c);
				premier.put(c, valeur);
			}
		}
		boolean changement=false;
		do {
			changement=false;
			for(Categorie c:Categorie.values()) {
				if(c.estNonTerminal()) {
					TreeSet<Categorie> set=premier.get(c);
					if(set==null)
						set=new TreeSet<Categorie>();
					if(nullable.get(c)) {
						if(set.add(Categorie.NUL)) {
							changement=true;
							premier.put(c, set);
						}
					}
					
					ArrayList<ArrayList<Categorie>> valeur=production.get(c);
					for(int i=0;i<valeur.size();i++) {
						ArrayList<Categorie> prod=valeur.get(i);
						Categorie elt=prod.get(0);
						if(premier.get(elt)!=null && !nullable.get(elt)) {
							for(Iterator<Categorie> it=premier.get(elt).iterator();it.hasNext();) {
								Categorie ca=it.next();
								if(!ca.equals(Categorie.NUL) && set.add(ca)) {
									changement=true;
									premier.put(c, set);
								}
							}
						}
						
						for(int j=1;j<prod.size();j++) {
							if(nullable.get(prod.get(j-1))) {
								elt=prod.get(j);
								if(premier.get(elt)!=null && !nullable.get(elt)) {
									for(Iterator<Categorie> it=premier.get(elt).iterator();it.hasNext();) {
										Categorie ca=it.next();
										if(!ca.equals(Categorie.NUL) && set.add(ca)) {
											changement=true;
											premier.put(c, set);
										}
									}
								}
							}
							else
								break;
						}	
					}	
				}
			}
		}
		while(changement);
	}
	
	private boolean ajouterSuivant(Categorie c1, Categorie c2) {
		boolean rep=false;
		if(c1.estNonTerminal() && c2.estNonTerminal()) {
			TreeSet<Categorie> set2=suivant.get(c2);
			TreeSet<Categorie> set1=suivant.get(c1);
			if(set1==null)
				set1=new TreeSet<Categorie>();
			if(set2!=null) {
				for(Iterator<Categorie> it=set2.iterator();it.hasNext();)
					rep=set1.add(it.next());
				suivant.put(c1, set1);
			}
		}
		return rep;
	}
	
	private boolean ajouterPremier(Categorie c1, Categorie c2) {
		boolean rep=false;
		if(c1.estNonTerminal()) {
			TreeSet<Categorie> set2=premier.get(c2);
			TreeSet<Categorie> set1=suivant.get(c1);
			if(set1==null)
				set1=new TreeSet<Categorie>();
			if(set2!=null) {
				for(Iterator<Categorie> it=set2.iterator();it.hasNext();) {
					Categorie ca=it.next();
					if(!ca.equals(Categorie.NUL))
						rep=set1.add(ca);
				}
				suivant.put(c1, set1);
			}
		}
		return rep;
	}
	
	public void calculSuivant() {
		TreeSet<Categorie> set=new TreeSet<Categorie>();
		set.add(Categorie.$);
		suivant.put(axiome, set);
		
		for(Categorie c:Categorie.values()) {
			if(c.estNonTerminal()) {
				ArrayList<ArrayList<Categorie>> productions=production.get(c);
				for(ArrayList<Categorie> uneProduction:productions) {
					for(int i=0;i<uneProduction.size()-1;i++) {
						for(int j=i+1;j<uneProduction.size();j++) {
							Categorie c1=uneProduction.get(j);
							ajouterPremier(uneProduction.get(i), c1);
							if(nullable.get(c1)!=null && !nullable.get(c1))
								break;
						}
					}
				}
			}
		}
		
		boolean continuer=true;
		while(continuer) {
			continuer=false;
			for(Categorie c:Categorie.values()) {
				if(c.estNonTerminal()) {
					ArrayList<ArrayList<Categorie>> productions=production.get(c);
					for(ArrayList<Categorie> uneProduction:productions) {
						for(int i=uneProduction.size()-1;i>=0;i--) {
							Categorie c1=uneProduction.get(i);
							continuer=ajouterSuivant(c1, c);
							if(nullable.get(c1)!=null && !nullable.get(c1))
								break;
						}
					}
				}
			}
		}
		
	}
	
	public void calculPremierRegles() {
		for(Categorie c:Categorie.values()) {
			if(c.estNonTerminal()) {
				ArrayList<ArrayList<Categorie>> productions=production.get(c);
				for(ArrayList<Categorie> uneProduction:productions) {
					TreeSet<Categorie> set=premierRegles.get(uneProduction);
					if(set==null)
						set=new TreeSet<Categorie>();
					for(int i=0;i<uneProduction.size();i++) {
						Categorie X=uneProduction.get(i);
						TreeSet<Categorie> premierX=premier.get(X);
						int j=0;
						for(Categorie ca:premierX) {
							if(!ca.equals(Categorie.NUL))
								set.add(ca);
						}
						if(nullable.get(X)!=null && !nullable.get(X))
							break;
						else
							if(nullable.get(X) && i==uneProduction.size()-1)
								set.add(Categorie.NUL);
					}
					premierRegles.put(uneProduction, set);
				}
			}
		}
	}
	
	public int indice(Categorie c) {
		if(c.estNonTerminal()) {
			return c.ordinal()-Categorie.MAX-1;
		}
		if(c.estTerminal()) {
			return c.ordinal()-Categorie.MIN;
		}
		if(c.equals(Categorie.$))
			return TA[0].length-1;
		return -1;
			
	}
	
	public void remplirTableAnalyse() {
		for(int i=0;i<TA.length;i++)
			for(int j=0;j<TA[i].length;j++)
				TA[i][j]=null;
		
		for(Categorie c:Categorie.values()) {
			int n1,n2;
			if(c.estNonTerminal()) {
				n1=indice(c);
				ArrayList<ArrayList<Categorie>> productions=production.get(c);
				for(ArrayList<Categorie> uneProduction:productions) {
					TreeSet<Categorie> premierX=premierRegles.get(uneProduction);
					for(Iterator<Categorie> it=premierX.iterator();it.hasNext();) {
						Categorie ca=it.next();
						if(ca.equals(Categorie.NUL)) {
							TreeSet<Categorie> suivantA=suivant.get(c);
							for(Iterator<Categorie> it1=suivantA.iterator();it1.hasNext();) {
								Categorie ca1=it1.next();
								n2=indice(ca1);
								TA[n1][n2]=uneProduction;
							}
						}
						else {
							n2=indice(ca);
							TA[n1][n2]=uneProduction;
						}
					}
				}
			}
		}
		
		
	}
	
	public void analyserSyntaxe(Categorie a) {
		int iX,ia;
		ia=indice(a);
		boolean accepter;
	do {	
		accepter=false;
		Categorie X=pile.peek();
		if(X.estNonTerminal()) {
			iX=indice(X);
			ArrayList<Categorie> regle=(ArrayList<Categorie>)TA[iX][ia];
			if(regle==null) {
				System.err.println("La grammaire n'est pas de type LL1");
				System.exit(0);
			}
			else {
				pile.pop();
				for(int i=regle.size()-1;i>=0;i--) {
					Categorie Y=regle.get(i);
					if(!Y.equals(Categorie.NUL)) {
						pile.push(Y);
					}
				}
				//System.out.println(X+" --> "+regle);
			}
		}
		else
			if(X.equals(Categorie.$)) {
				if(a==Categorie.$) {
					System.out.println("La grammaire est de type LL1");
					return;
				}
				else {
					System.err.println("La grammaire n'est pas de type LL1");
					System.exit(0);
				}
			}
			else
				if(X.equals(a)) {
					pile.pop();
					accepter=true;
				}
				else {
					System.err.println("ERREUR DE SYNTAXE!!!");
					System.exit(0);
				}
		
	}
	while(!accepter);
		
		
		
	}
	
	
	
	
	
}
